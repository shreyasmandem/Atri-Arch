"""The seam between this pipeline and the shipped reasoner.

Written blind: `backend/` was not uploaded, so the two functions below name what
they need rather than calling your real code. Point them at
`aip.engines.vastu.reasoner` and the rest of the pipeline is unchanged.

The contract is narrow on purpose -- one call per plan, returning per-rule
satisfaction and assessability. If the reasoner cannot currently return those
two vectors separately, that is the first thing to fix, because collapsing
"scored 0" and "not assessable" into one number is the exact failure the corpus
already refuses elsewhere.
"""

from __future__ import annotations

from typing import Any, Callable, Iterable

import numpy as np

from .schema import CalibrationSet, PlanObservation, RuleCard


def cards_from_corpus(corpus: Iterable[Any]) -> tuple[RuleCard, ...]:
    """Expected per rule object: .rule_id / .id, .provenance, .modern_validity,
    and .weight if the corpus already carries a hand-set weight.

    Ordering is fixed here and must not change between building the panel set
    and fitting -- the design matrix is positional.
    """
    cards = []
    for rule in corpus:
        rid = getattr(rule, "rule_id", None) or getattr(rule, "id")
        cards.append(
            RuleCard(
                rule_id=str(rid),
                provenance=str(getattr(rule, "provenance", "contemporary")),
                modern_validity=float(getattr(rule, "modern_validity", 1.0)),
                prior_weight=float(getattr(rule, "weight", 1.0)),
            )
        )
    return tuple(sorted(cards, key=lambda c: c.rule_id))


def observation_from_report(
    plan_id: str, report: Any, cards: tuple[RuleCard, ...],
) -> PlanObservation:
    """Expected per finding in `report`: .rule_id, .satisfaction in [0,1], and
    .assessable (or a status of "not_assessable").

    A rule absent from the report is treated as not assessable, never as zero.
    """
    by_rule = {}
    for f in getattr(report, "findings", report):
        rid = str(getattr(f, "rule_id", None) or getattr(f, "id"))
        status = str(getattr(f, "status", "")).lower()
        assessable = bool(getattr(f, "assessable", status != "not_assessable"))
        by_rule[rid] = (float(getattr(f, "satisfaction", 0.0)), assessable)

    sat = np.zeros(len(cards))
    msk = np.zeros(len(cards), dtype=bool)
    for i, c in enumerate(cards):
        if c.rule_id in by_rule:
            sat[i], msk[i] = by_rule[c.rule_id]
    return PlanObservation(
        plan_id=plan_id,
        rule_ids=tuple(c.rule_id for c in cards),
        satisfaction=sat,
        assessable=msk,
    )


def build_set(
    plans: dict[str, Any],
    cards: tuple[RuleCard, ...],
    evaluate: Callable[[Any], Any],
) -> CalibrationSet:
    """`evaluate` is the reasoner call: design -> report."""
    cs = CalibrationSet(cards=cards)
    for pid, design in plans.items():
        cs.add_plan(observation_from_report(pid, evaluate(design), cards))
    return cs


def write_back(weights: dict[str, float], identifiable: dict[str, bool],
               prior: dict[str, float]) -> dict[str, float]:
    """Only weights the bootstrap identified are allowed to change.

    Everything else keeps the editor's value, so a rule the panel never
    exercised is not quietly re-weighted by noise.
    """
    return {
        rid: (weights[rid] if identifiable.get(rid, False) else prior.get(rid, 1.0))
        for rid in weights
    }
